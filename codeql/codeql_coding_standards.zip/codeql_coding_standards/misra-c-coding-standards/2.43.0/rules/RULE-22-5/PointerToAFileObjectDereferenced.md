# Rule 22.5: A pointer to a FILE object shall not be dereferenced

This query implements the MISRA C 2012 Rule 22.5:
> A pointer to a FILE object shall not be dereferenced.

## Classification

<table>
<tr><td><b>Category</b></td><td>Mandatory</td></tr>
<tr><td><b>Analysis</b></td><td>Undecidable, System</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

## Amplification

A pointer to a FILE object shall not be dereferenced directly or indirectly (e.g. by a call to `memcpy` or `memcmp`).

## Rationale

Within the section on “files”, the C Standard states that the address of a FILE object used to control a stream may be significant and a copy of the object may not give the same behavior. This rule ensures that such a copy cannot be made.
The direct manipulation of a FILE object is prohibited as this may be incompatible with its use as a stream designator.

## Example

```c
#include <stdio.h>
FILE *pf1;
FILE *pf2;
FILE  f3;

pf2 = pf1;      /* Compliant     */
f3 = *pf2;      /* Non-compliant */

/* The following example assumes that FILE * specifies a complete type with a member named pos: */
pf1->pos = 0;   /* Non-compliant */
```

## See also

Rule 21.6