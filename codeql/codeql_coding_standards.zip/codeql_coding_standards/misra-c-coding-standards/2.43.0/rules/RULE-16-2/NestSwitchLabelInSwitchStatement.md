# Rule 16.2: A switch label shall only be used when the most closely-enclosing compound statement is the body of a switch statement

This query implements the MISRA C 2012 Rule 16.2:
> A switch label shall only be used when the most closely-enclosing compound statement is the body of a switch statement.

## Classification

<table>
<tr><td><b>Category</b></td><td>Required</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

## Rationale

The C Standard permits a switch label, i.e. a case label or default label, to be placed before any statement contained in the body of a switch statement, potentially leading to unstructured code. In order to prevent this, a switch label shall only appear at the outermost level of the compound statement forming the body of a switch statement.

## Example

```c
switch ( x )
{
  case 1:         /* Compliant     */
    if ( flag )
    {
  case 2:         /* Non-compliant */
      x = 1;
    }
    break;
  default:
    break;
}
```

## See also

Rule 16.1