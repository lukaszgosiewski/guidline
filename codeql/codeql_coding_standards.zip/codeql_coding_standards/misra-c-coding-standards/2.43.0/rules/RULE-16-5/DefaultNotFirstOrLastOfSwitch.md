# Rule 16.5: A default label shall appear as either the first or the last switch label of a switch statement

This query implements the MISRA C 2012 Rule 16.5:
> A default label shall appear as either the first or the last switch label of a switch statement.

## Classification
<table>
<tr><td><b>Category</b></td><td>Required</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

## Rationale
This rule makes it easy to locate the default label within a switch statement.

## Example
```c
switch ( x )
{
  default:   /* Compliant - default is the first label                */
  case 0:
    ++x;
    break;
  case 1:
  case 2:
    break;
}
switch ( x )
{
  case 0:
    ++x;
    break;
  default:   /* Non-compliant - default is mixed with the case labels */
    x = 0;
    break;
  case 1:
  case 2:
    break;
}
```
```c
switch ( x )
{
  case 0:
    ++x;
    break;
  case 1:
  case 2:
    break;
  default:   /* Compliant - default is the final label                */
    x = 0;
    break;
}
```

## See also
Rule 15.7, Rule 16.1