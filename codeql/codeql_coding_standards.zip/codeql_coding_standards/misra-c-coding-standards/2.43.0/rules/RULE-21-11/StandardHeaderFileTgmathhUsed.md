# Rule 21.11: The standard header file `<tgmath.h>` should not be used

This query implements the MISRA C 2012 Rule 21.11:
> The standard header file `<tgmath.h>` should not be used.

## Classification
<table>
<tr><td><b>Category</b></td><td>Advisory</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C99, C11</td></tr>
</table>

### Amplification
The standard header file `<tgmath.h>` should not be `#include`'d.
Note: Due to the duplication of macro names between `<tgmath.h>`, `<math.h>` and `<complex.h>` this rule does not have the additional requirement that none of the features that are specified as being provided by `<tgmath.h>` should be used, as use by means of `#including` either of these other standard header files is not constrained. Any other definition of a macro specified as being provided by `<tgmath.h>` will be a violation of Rule 21.1 and/or Rule 21.2.

### Rationale
Using the facilities of `<tgmath.h>` may result in undefined behaviour.

### Example
```c
#include <tgmath.h>
float f1, f2;
void f ( void )
{
  f1 = sqrt ( f2 );    /* Non-compliant - generic sqrt used      */
}

#include <math.h>
float f1, f2;
void f ( void )
{
  f1 = sqrtf ( f2 );   /* Compliant - float version of sqrt used */
}
```

## References
C99 [Undefined 184, 185], C11 [Undefined 195, 196]