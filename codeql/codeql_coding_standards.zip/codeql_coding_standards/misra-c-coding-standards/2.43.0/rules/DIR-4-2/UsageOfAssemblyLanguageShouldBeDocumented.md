# Dir 4.2: All usage of assembly language should be documented

This query implements the MISRA C 2012 Directive 4.2:
> All usage of assembly language should be documented.

## Classification
<table>
<tr><td><b>Category</b></td><td>Advisory</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

### Amplification
The rationale for the use of the assembly language and the mechanism for interfacing between C and the assembly language should be documented.

### Rationale
Assembly language code is implementation-defined and therefore not portable.