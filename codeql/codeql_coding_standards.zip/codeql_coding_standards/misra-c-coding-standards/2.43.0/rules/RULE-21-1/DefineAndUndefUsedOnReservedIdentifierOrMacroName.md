# Rule 21.1: `#define` and `#undef` shall not be used on a reserved identifier or reserved macro name

This query implements the MISRA C 2012 Rule 21.1:
> #define and #undef shall not be used on a reserved identifier or reserved macro name.

## Classification

<table>
<tr><td><b>Category</b></td><td>Required</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

## Amplification
This rule applies to the following:
- Identifiers or macro names beginning with an underscore;
- Identifiers in file scope described in Section 7, “Library”, of the C Standard;
- Macro names described in Section 7, “Library”, of the C Standard as being defined in a standard header.

This rule also prohibits the use of `#define` or `#undef` on the identifier `defined` as this results in explicitly undefined behaviour.

This rule does not include those identifiers or macro names that are described in the section of the applicable C Standard entitled “Future Library Directions”. The C Standard states that defining a macro with the same name as:
- A macro defined in a standard header, or
- An identifier with file scope declared in a standard header
is well-defined provided that the header is not included. This rule does not permit such definitions on the grounds that they are likely to cause confusion.

Note: the macro `NDEBUG` is not defined in a standard header and may therefore be `#define`d.

## Rationale
Reserved identifiers and reserved macro names are intended for use by the implementation. Removing or changing the meaning of a reserved macro may result in undefined behaviour.

## Example
```c
#undef  __LINE__                 /* Non-compliant - begins with _        */
#define _GUARD_H 1               /* Non-compliant - begins with _        */
#undef  _BUILTIN_sqrt            /* Non-compliant - the implementation
                                  * may use _BUILTIN_sqrt for other
                                  * purposes, e.g. generating a sqrt* instruction                          */

#define defined                  /* Non-compliant - reserved identifier  */
#define errno my_errno           /* Non-compliant - library identifier   */
#define isneg( x ) ( ( x ) < 0 ) /* Compliant     - rule doesn't include
                                  *                 future library
                                  *                 directions           */
```

## See also
Rule 20.4, Rule 20.5

## References
C90 [Undefined 54, 57, 58, 62, 71]  
C99 [Undefined 93, 100, 101, 104, 108, 116, 118, 130]  
C11 [Undefined 99, 106, 107, 110, 114, 122, 126, 138]