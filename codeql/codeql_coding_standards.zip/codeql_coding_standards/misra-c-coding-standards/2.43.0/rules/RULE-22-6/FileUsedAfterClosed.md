# Rule 22.6: The value of a pointer to a FILE shall not be used after the associated stream has been closed

This query implements the MISRA C 2012 Rule 22.6:
> The value of a pointer to a FILE shall not be used after the associated stream has been closed.

## Classification

<table>
<tr><td><b>Category</b></td><td>Mandatory</td></tr>
<tr><td><b>Analysis</b></td><td>Undecidable, System</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

## Rationale

The C Standard states that the value of a FILE pointer is indeterminate after a close operation on a stream.

## Example

```c
#include <stdio.h>
void fn ( void )
{
  FILE *fp;
  void *p;
  fp = fopen ( "tmp", "w" );
  if ( fp == NULL )
  {
    error_action ( );
  }
  fclose ( fp );
  fprintf ( fp, "?" );   /* Non-compliant */
  p = fp;                /* Non-compliant */
}
```

## See also

Dir 4.13, Rule 21.6

## References

C99 [Undefined 140], C11 [Undefined 148]