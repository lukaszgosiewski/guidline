# Rule 20.6: Tokens that look like a preprocessing directive shall not occur within a macro argument

This query implements the MISRA C 2012 Rule 20.6:
> Tokens that look like a preprocessing directive shall not occur within a macro argument.

## Classification

<table>
<tr><td><b>Category</b></td><td>Required</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

## Rationale

An argument containing sequences of tokens that would otherwise act as preprocessing directives leads to undefined behaviour.

## Example

```c
#define M( A ) printf ( #A )
#include <stdio.h>
void main ( void )
{
  M (
#ifdef SW            /* Non-compliant */
       "Message 1"#else                /* Non-compliant */
       "Message 2"
#endif               /* Non-compliant */
    );
}
```

The above may print
```
#ifdef SW "Message 1" #else "Message 2" #endif
```
or
```
"Message 2"
```
or exhibit some other behaviour.

## References

C90 [Undefined 50], C99 [Undefined 87], C11 [Undefined 93]