# Rule 21.6: The Standard Library input/output functions shall not be used

This query implements the MISRA C 2012 Rule 21.6:
> The Standard Library input/output functions shall not be used.

## Classification

<table>
<tr><td><b>Category</b></td><td>Required</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

## Amplification

This rule applies to the functions that are specified as being provided by `<stdio.h>` and the wide-character equivalents specified as being provided by `<wchar.h>`. None of these identifiers shall be used and no macro with one of these names shall be expanded.

## Rationale

Streams and file I/O have unspecified, undefined and implementation-defined behaviours associated with them.

## See also

Rule 22.1, Rule 22.3, Rule 22.4, Rule 22.5, Rule 22.6

## References

C90 [Unspecified 2–5, 16–18; Undefined 77–89; Implementation 53–68]
C99 [Unspecified 3–6, 34–37; Undefined 138–166, 186; Implementation J.3.12(14–32)]
C11 [Unspecified 4–7, 37-40; Undefined 146–175, 198; Implementation J.3.12(16–34)]