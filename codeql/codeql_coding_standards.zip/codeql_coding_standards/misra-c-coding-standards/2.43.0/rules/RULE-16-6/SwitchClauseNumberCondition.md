# Rule 16.6: Every switch statement shall have at least two switch-clauses

This query implements the MISRA C 2012 Rule 16.6:
> Every switch statement shall have at least two switch-clauses.

## Classification
<table>
<tr><td><b>Category</b></td><td>Required</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

## Rationale
A switch statement with a single path is redundant and may be indicative of a programming error.

## Example
```c
switch ( x ) 
{
  default:   /* Non-compliant - switch is redundant */
    x = 0;
    break;
}

switch ( y ) 
{
  case 1:
  default:   /* Non-compliant - switch is redundant */
    y = 0;
    break;
}

switch ( z ) 
{
  case 1:
    z = 2;
    break;
  default:   /* Compliant */
    z = 0;
    break;
}
```

## See also
Rule 16.1