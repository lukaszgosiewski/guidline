# Rule 11.8: A conversion shall not remove any const, volatile or _Atomic qualification from the type pointed to by a pointer

This query implements the MISRA C 2012 Rule 11.8:
> A conversion shall not remove any const, volatile or _Atomic qualification from the type pointed to by a pointer.

## Classification
<table>
<tr><td><b>Category</b></td><td>Required</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

### Rationale
Any attempt to remove the qualification associated with the addressed type is a violation of the principle of type qualification.
Note: the qualification referred to here is not the same as any qualification that may be applied to the pointer itself.
Some of the problems that might arise if a qualifier is removed from the addressed object are:
* Removing a const qualifier might circumvent the read-only status of an object and result in it being modified;
* Removing a const qualifier might result in an exception when the object is accessed;
* Removing a volatile qualifier might result in accesses to the object being optimized away.
* Removing an _Atomic qualifier might circumvent the lock status of an object and potentially result in memory corruption.
Note: removal of the restrict type qualifier (C99 and later) is benign.

### Example
```c
     uint16_t          x;
     uint16_t * const  cpi = &x;   /* const pointer               */
     uint16_t * const *pcpi;       /* pointer to const pointer    */
     uint16_t *       *ppi;
const uint16_t         *pci;        /* pointer to const            */
volatile uint16_t      *pvi;        /* pointer to volatile         */
     uint16_t         *pi;
pi = cpi;                              /* Compliant - no conversion
                                                   no cast required   */
pi  = (uint16_t *)pci;                 /* Non-compliant               */
pi  = (uint16_t *)pvi;                 /* Non-compliant               */
ppi = (uint16_t * *)pcpi;              /* Non-compliant               */
typedef struct s {
  uint8_t a;
  uint8_t b;
} s_t;
int main( void )
{
  _Atomic s_t  astr;
          s_t  lstr = { 7U, 42U };
          s_t *sptr = &astr;         /* Non-compliant - removes _Atomic qualifier */
}
```

### See also
Rule 11.3, Rule 11.10

## References
C90 [Undefined 12, 39, 40], C99 [Undefined 30, 61, 62], C11 [Undefined 33, 64, 65]