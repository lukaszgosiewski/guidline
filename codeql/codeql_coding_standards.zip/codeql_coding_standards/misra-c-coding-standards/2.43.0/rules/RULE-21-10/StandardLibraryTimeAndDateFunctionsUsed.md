# Rule 21.10: The Standard Library time and date functions shall not be used

This query implements the MISRA C 2012 Rule 21.10:
> The Standard Library time and date functions shall not be used.

## Classification
<table>
<tr><td><b>Category</b></td><td>Required</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

## Amplification
This rule applies to the functions that are specified as being provided by `<time.h>` and the function `wcsftime` provided by `<wchar.h>`.

The standard header file `<time.h>` shall not be `#include`'d, and none of the features that are specified as being provided by `<time.h>` shall be used.

For C99 or later, the function `wcsftime` shall not be used and no macro with this name shall be expanded.

## Rationale
The time and date functions have unspecified, undefined, and implementation-defined behaviors associated with them.

## References
C90 [Unspecified 22; Undefined 80, 97; Implementation 75, 76]  
C99 [Unspecified 43, 44; Undefined 146, 154, 182; Implementation J.3.12(39–42)]  
C11 [Unspecified 48, 49; Undefined 154, 162, 193, 197; Implementation J.3.12(41-45)]