# Rule 11.7: A cast shall not be performed between pointer to object and a non-integer arithmetic type

This query implements the MISRA C 2012 Rule 11.7:
> A cast shall not be performed between pointer to object and a non-integer arithmetic type.

## Classification
<table>
<tr><td><b>Category</b></td><td>Required</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

## Amplification
For the purposes of this rule a non-integer arithmetic type means one of:
- Essentially Boolean
- Essentially character
- Essentially enum
- Essentially floating

## Rationale
Conversion of an essentially Boolean, essentially character or essentially enum type into a pointer to an object may result in a pointer that is not correctly aligned, resulting in undefined behaviour.  
Conversion of a pointer to an object into an essentially Boolean, essentially character or essentially enum type may produce a value that cannot be represented in the chosen integer type resulting in undefined behaviour.  
Conversion of a pointer to an object into or from an essentially floating type results in undefined behaviour.

## Example
```c
int16_t  *p;
float32_t f;
f = ( float32_t ) p;   /* Non-compliant */
p = ( int16_t * ) f;   /* Non-compliant */
```

## See also
Rule 11.4

## References
C90 [Undefined 29; Implementation 24]  
C99 [Undefined 21, 41; Implementation J.3.7(1)]  
C11 [Undefined 24, 44; Implementation J.3.7(1)]