# Rule 2.7: A function should not contain unused parameters

This query implements the MISRA C 2012 Rule 2.7:
> A function should not contain unused parameters.

## Classification

<table>
<tr><td><b>Category</b></td><td>Advisory</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

### Rationale

Most functions will be specified as using each of their parameters. If a function parameter is unused, it is possible that the implementation of the function does not match its specification. This rule highlights such potential mismatches.

### Example

```c
void withunusedpara ( uint16_t *para1, 
                      int16_t   unusedpara )   /* Non-compliant - unused */
{
  *para1 = 42U;
}
```