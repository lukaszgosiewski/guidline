# Rule 22.1: All resources obtained dynamically by means of Standard Library functions shall be explicitly released

This query implements the MISRA C 2012 Rule 22.1:  
> All resources obtained dynamically by means of Standard Library functions shall be explicitly released.

## Classification
<table>
<tr><td><b>Category</b></td><td>Required</td></tr>
<tr><td><b>Analysis</b></td><td>Undecidable, System</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

## Amplification
This rule applies to `malloc`, `calloc`, `realloc`, `aligned_alloc`, and `fopen`.

## Rationale
If resources are not explicitly released then it is possible for a failure to occur due to exhaustion of those resources. Releasing resources as soon as possible reduces the possibility that exhaustion will occur.

## Example
```c
#include <stdlib.h>
int main ( void )
{
  void *b = malloc ( 40 ); /* Non-compliant - dynamic memory not released */
  return 1;
}

#include <stdio.h>
int main ( void )
{
  FILE *fp = fopen ( "tmp", "r" );
  /* Non-compliant - file not closed */
  return 1;
}
```

In the following non-compliant example, the handle on "tmp-1" is lost when "tmp-2" is opened.

```c
#include <stdio.h>
int main ( void )
{
  FILE *fp;
  fp = fopen ( "tmp-1", "w" );
  fprintf ( fp, "*" );
  /* File "tmp-1" should be closed here, but stream 'leaks' */
  fp = fopen ( "tmp-2", "w" );
  fprintf ( fp, "!" );
  fclose ( fp );
  return ( 0 );
}
```
## See also
Dir 4.12, Dir 4.13, Rule 21.3, Rule 21.6