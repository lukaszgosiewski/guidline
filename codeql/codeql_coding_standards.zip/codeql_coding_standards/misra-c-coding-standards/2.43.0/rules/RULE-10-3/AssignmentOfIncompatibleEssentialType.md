# Rule 10.3: The value of an expression shall not be assigned to an object with a narrower essential type or of a different essential type category

This query implements the MISRA C 2012 Rule 10.3:
> The value of an expression shall not be assigned to an object with a narrower essential type or of a different essential type category.

## Classification
<table>
<tr><td><b>Category</b></td><td>Required</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

## Amplification
The following operations are covered by this rule:
1. Assignment as defined in the Glossary;
2. The conversion of the constant expression in a switch statement's case label to the essential type of the controlling expression.

## Rationale
The C language allows the programmer considerable freedom and will permit assignments between different arithmetic types to be performed automatically. However, the use of these implicit conversions can lead to unintended results, with the potential for loss of value, sign or precision. Further details of concerns with the C type system can be found in Appendix C.

The use of stronger typing, as enforced by the MISRA essential type model, reduces the likelihood of these problems occurring.

## Exception
1. An essentially signed integer constant expression, with a rank no greater than signed int, may be assigned to an object of essentially unsigned type if its value can be represented in that type.
2. The initializer { 0 } may be used to initialize an aggregate or union type.
3. A switch statement's case label that is a non-negative integer constant expression of essentially signed type is permitted when the controlling expression is of essentially unsigned type and the value can be represented in that type.
4. An essentially real floating expression may be assigned to an object of essentially complex floating type provided that its corresponding real type is not narrower than the type of the expression.

## References
C90 [Undefined 15; Implementation 16]  
C99 [Undefined 15, 16; Implementation J.3.5(4)]  
C11 [Undefined 17, 18; Implementation J.3.5(4)]