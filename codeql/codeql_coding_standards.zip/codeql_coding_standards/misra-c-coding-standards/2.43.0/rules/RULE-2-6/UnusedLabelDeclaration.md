# Rule 2.6: A function should not contain unused label declarations

This query implements the MISRA C 2012 Rule 2.6:
> A function should not contain unused label declarations.

## Classification

<table>
<tr><td><b>Category</b></td><td>Advisory</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

## Rationale

If a label is declared but not used, then it is unclear to a reviewer if the label is redundant or it has been left unused by mistake.

## Example

```c
void unused_label ( void )
{
  int16_t x = 6;
label1:              /* Non-compliant */
  use_int16 ( x );
}
```