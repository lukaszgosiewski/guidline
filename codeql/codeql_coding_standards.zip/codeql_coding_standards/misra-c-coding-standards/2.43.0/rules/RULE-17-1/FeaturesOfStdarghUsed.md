# Rule 17.1: The standard header file `<stdarg.h>` shall not be used

This query implements the MISRA C 2012 Rule RULE-17-1:
> The standard header file `<stdarg.h>` shall not be used.

## Classification

<table>
<tr><td><b>Category</b></td><td>Required</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

## Amplification

The standard header file `<stdarg.h>` shall not be `#include`'d, and none of the features that are specified as being provided by `<stdarg.h>` shall be used.

## Rationale

The C Standard lists many instances of undefined behaviour associated with the features of `<stdarg.h>`, including:
- `va_end` not being used prior to end of a function in which `va_start` was used;
- `va_arg` being used in different functions on the same `va_list`;
- The type of an argument not being compatible with the type specified to `va_arg`.

## Example

```c
#include <stdarg.h>
void h ( va_list ap )            /* Non-compliant                     */
{
  double y;
  y = va_arg ( ap, double );     /* Non-compliant                     */
}
void f ( uint16_t n, ... )
{
  uint32_t x;
  va_list  ap;                   /* Non-compliant                     */
  va_start ( ap, n );            /* Non-compliant                     */
  x = va_arg ( ap, uint32_t );   /* Non-compliant                     */
  h ( ap );
  /* undefined - ap is indeterminate because va_arg used in h ( )     */
  x = va_arg ( ap, uint32_t );   /* Non-compliant                     */
  /* undefined - returns without using va_end (  )                    */
}
void g ( void )
{
  /* undefined - uint32_t:double type mismatch when f uses va_arg ( ) */
  f ( 1, 2.0, 3.0 );
}
```

## References

C90 [Undefined 45, 70–76]  
C99 [Undefined 81, 128–135]  
C11 [Undefined 87, 136–143]