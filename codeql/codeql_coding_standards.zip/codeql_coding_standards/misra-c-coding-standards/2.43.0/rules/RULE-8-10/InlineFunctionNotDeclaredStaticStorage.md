# Rule 8.10: An inline function shall be declared with the static storage class

This query implements the MISRA C 2012 Rule 8.10:
> An inline function shall be declared with the static storage class.

## Classification

<table>
<tr><td><b>Category</b></td><td>Required</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C99, C11</td></tr>
</table>

## Rationale

If an inline function is declared with external linkage but not defined in the same translation unit, the behaviour is undefined. A call to an inline function declared with external linkage may call the external definition of the function, or it may use the inline definition. Although this should not affect the behaviour of the called function, it might affect execution timing and therefore have an impact on a real-time program.

Note: an inline function can be made available to several translation units by placing its definition in a header file.

## References

C99 [Unspecified 20; Undefined 67], C99 [Unspecified 21; Undefined 70]