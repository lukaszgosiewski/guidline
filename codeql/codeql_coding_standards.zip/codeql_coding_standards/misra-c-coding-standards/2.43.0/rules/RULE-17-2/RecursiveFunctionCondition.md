# Rule 17.2: Functions shall not call themselves, either directly or indirectly

This query implements the MISRA C 2012 Rule 17.2:
> Functions shall not call themselves, either directly or indirectly.

## Classification
<table>
<tr><td><b>Category</b></td><td>Required</td></tr>
<tr><td><b>Analysis</b></td><td>Undecidable, System</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

## Rationale
Recursion carries with it the danger of exceeding available stack space, which can lead to failure. 
Unless recursion is very tightly controlled, it is not possible to determine before execution what the 
worst-case stack usage could be.