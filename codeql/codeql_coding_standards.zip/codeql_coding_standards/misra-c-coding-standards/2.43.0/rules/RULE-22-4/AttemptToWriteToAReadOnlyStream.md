# Rule 22.4: There shall be no attempt to write to a stream which has been opened as read-only

This query implements the MISRA C 2012 Rule 22.4:
> There shall be no attempt to write to a stream which has been opened as read-only.

## Classification

<table>
<tr><td><b>Category</b></td><td>Mandatory</td></tr>
<tr><td><b>Analysis</b></td><td>Undecidable, System</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

## Rationale

The C Standard does not specify the behaviour if an attempt is made to write to a read-only stream. For this reason it is considered unsafe to write to a read-only stream.

## Example

```c
#include <stdio.h>
void fn ( void )
{
  FILE *fp = fopen ( "tmp", "r" );
  ( void ) fprintf ( fp, "What happens now?" );   /* Non-compliant */
  ( void ) fclose ( fp );
}
```

## See also

Rule 21.6