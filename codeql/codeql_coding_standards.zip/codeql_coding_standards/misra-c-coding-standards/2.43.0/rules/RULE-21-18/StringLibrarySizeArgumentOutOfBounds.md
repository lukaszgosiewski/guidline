# Rule 21.18: The size_t argument passed to any function in <string.h> shall have an appropriate value

This query implements the MISRA C 2012 Rule 21.18:
> The size_t argument passed to any function in <string.h> shall have an appropriate value.

## Classification
<table>
<tr><td><b>Category</b></td><td>Mandatory</td></tr>
<tr><td><b>Analysis</b></td><td>Undecidable, System</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

## Amplification
The relevant functions in `<string.h>` are:
- `memchr`
- `memcmp`
- `memcpy`
- `memmove`
- `memset`
- `strncat`
- `strncmp`
- `strncpy`
- `strxfrm`

An appropriate value is:
- Positive;
- No greater than the size of the smallest object passed to the function through a pointer parameter.

## Rationale
Incorrect use of a function listed above may result in a read or write access beyond the bounds of an object passed as a parameter, resulting in undefined behaviour.

## Example
```c
char buf1[5] = "12345";
char buf2[10] = "1234567890";

void f(void)
{ 
  if (memcmp(buf1, buf2, 5) == 0)                  /* Compliant     */
  {
  }
  if (memcmp(buf1, buf2, 6) == 0)                  /* Non-compliant */
  {
  }
}
```

## See also
Rule 21.17
  
## References
- C90 [Undefined 96]
- C99 [Undefined 103, 180, 181]
- C11 [Undefined 109, 191, 192]