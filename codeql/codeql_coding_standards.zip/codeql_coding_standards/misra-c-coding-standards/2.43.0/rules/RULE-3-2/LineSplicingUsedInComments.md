# Rule 3.2: Line-splicing shall not be used in // comments

This query implements the MISRA C 2012 Rule 3.2:
> Line-splicing shall not be used in // comments.

## Classification
<table>
<tr><td><b>Category</b></td><td>Required</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C99, C11</td></tr>
</table>

## Amplification
Line-splicing occurs when the `\` character is immediately followed by a new-line character. If the source file contains multibyte characters, they are converted to the source character set before any splicing occurs.

## Rationale
If the source line containing a `//` comment ends with a `\` character in the source character set, the next line becomes part of the comment. This may result in unintentional removal of code.

## Example
In the following non-compliant example, the physical line containing the `if` keyword is logically part of the previous line and is therefore a comment.

```c
extern bool_t b;
void f ( void )
{
  uint16_t  x = 0;   // comment \
  if ( b )
  {
    ++x;             /* This is always executed */
  }
}
```

## See also
Dir 4.4