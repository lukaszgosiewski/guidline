# Rule 20.8: The controlling expression of a #if or #elif preprocessing directive shall evaluate to 0 or 1

This query implements the MISRA C 2012 Rule 20.8:
> The controlling expression of a #if or #elif preprocessing directive shall evaluate to 0 or 1.

## Classification
<table>
<tr><td><b>Category</b></td><td>Required</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

## Amplification
This rule does not apply to controlling expressions in preprocessing directives which are not evaluated. Controlling expressions are not evaluated if they are within code that is being excluded and cannot have an effect on whether code is excluded or not.

## Rationale
Strong typing requires the controlling expression of conditional inclusion preprocessing directives to have a Boolean value.

## Example
```c
#define FALSE 0
#define TRUE  1
#if FALSE           /* Compliant                              */
#endif
#if 10              /* Non-compliant                          */
#endif
#if ! defined ( X ) /* Compliant                              */
#endif
#if A > B           /* Compliant assuming A and B are numeric */
#endif
```

## See also
Rule 14.4