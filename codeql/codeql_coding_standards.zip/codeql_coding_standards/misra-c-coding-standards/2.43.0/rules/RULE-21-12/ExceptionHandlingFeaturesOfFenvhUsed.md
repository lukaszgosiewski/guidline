# Rule 21.12: The standard header file `<fenv.h>` shall not be used

This query implements the MISRA C 2012 Rule 21.12:
> The standard header file `<fenv.h>` shall not be used.

## Classification
<table>
<tr><td><b>Category</b></td><td>Required</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C99, C11</td></tr>
</table>

## Amplification
The standard header file `<fenv.h>` shall not be `#include`'d, and none of the features that are specified as being provided by `<fenv.h>` shall be used.

## Rationale
In some circumstances, the values of the floating-point status flags are unspecified and attempts to access them may lead to undefined behaviour.

The order in which exceptions are raised by the `feraiseexcept` function is unspecified and could therefore result in a program that has been designed for a certain order not operating correctly.

Calling the `fesetenv` or `feupdateenv` functions with invalid arguments results in undefined behaviour.

Calling the `fesetround` function should be done with care because:
1. Setting the rounding mode may have unexpected consequences, e.g. setting the current rounding mode to upwards does not guarantee that the result of evaluating an expression is an upward approximation to the value of the expression over the reals.
2. Several implementations of functions declared in `<math.h>` have been designed to support round-to-nearest only: if such functions are called when a different rounding mode is set, the results can be unpredictable.

Note: In conforming implementations, the rounding direction mode is set to rounding to nearest at program start-up.

## Example
```c
#include <fenv.h>
void f ( float32_t x, float32_t y )
{
  float32_t z;
  feclearexcept ( FE_DIVBYZERO );         /* Non-compliant */
  z = x / y;
  if ( fetestexcept ( FE_DIVBYZERO ) )    /* Non-compliant */
  {
  }
  else
  {
#pragma STDC FENV_ACCESS ON
    z = x * y;
  }
  if ( z > x )
  {
#pragma STDC FENV_ACCESS OFF
    if ( fetestexcept ( FE_OVERFLOW ) )   /* Non-compliant */
    {}
  }
}
```

## References
C99 [Unspecified 27, 28; Undefined 109–112; Implementation J.3.6(8)]  
C11 [Unspecified 27, 28; Undefined 115–118; Implementation J.3.6(9)]