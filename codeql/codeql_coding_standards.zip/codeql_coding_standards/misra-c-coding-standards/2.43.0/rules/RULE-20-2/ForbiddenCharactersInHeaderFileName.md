# Rule 20.2: The ', " or \ characters and the /* or // character sequences shall not occur in a header file name

This query implements the MISRA C 2012 Rule 20.2:
> The ', " or \ characters and the /* or // character sequences shall not occur in a header file name.

## Classification
<table>
<tr><td><b>Category</b></td><td>Required</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

## Rationale
The behaviour is undefined if:
- The ', " or \ characters, or the /* or // character sequences are used between < and > delimiters in a header name preprocessing token;
- The ', " or \ characters, or the /* or // character sequences are used between the " delimiters in a header name preprocessing token.

Note: Although use of the \ character results in undefined behaviour, many implementations will accept the / character in its place.

## Example
```c
#include "fi'le.h"   /* Non-compliant */
```

## References
C90 [Undefined 14], C99 [Undefined 31], C11 [Undefined 34]