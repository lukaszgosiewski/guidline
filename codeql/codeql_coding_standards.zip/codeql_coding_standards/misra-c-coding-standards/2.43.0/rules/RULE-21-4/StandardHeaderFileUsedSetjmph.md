# Rule 21.4: The standard header file `<setjmp.h>` shall not be used

This query implements the MISRA C 2012 Rule 21.4:
> The standard header file `<setjmp.h>` shall not be used.

## Classification
<table>
<tr><td><b>Category</b></td><td>Required</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

## Amplification
The standard header file `<setjmp.h>` shall not be `#include`'d, and none of the features that are specified as being provided by `<setjmp.h>` shall be used.

## Rationale
`setjmp` and `longjmp` allow the normal function call mechanisms to be bypassed. Their use may lead to undefined and unspecified behaviour.

## References
C90 [Unspecified 14; Undefined 64–67]  
C99 [Unspecified 32; Undefined 118–121, 173]  
C11 [Unspecified 35; Undefined 124–127, 183]  
[Koenig 74]