# Rule 11.1: Conversions shall not be performed between a pointer to a function and any other type

This query implements the MISRA C 2012 Rule 11.1:
> Conversions shall not be performed between a pointer to a function and any other type.

## Classification
<table>
<tr><td><b>Category</b></td><td>Required</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

### Amplification
A pointer to a function shall only be converted into or from a pointer to a function with a compatible type.

### Rationale
The conversion of a pointer to a function into or from any of:
- Pointer to object;
- Pointer to incomplete;
- void *

results in undefined behaviour.

If a function is called by means of a pointer whose type is not compatible with the called function, the behaviour is undefined. Conversion of a pointer to a function into a pointer to a function with a different type is permitted by the C Standard. Conversion of an integer into a pointer to a function is also permitted by the C Standard. However, both are prohibited by this rule in order to avoid the undefined behaviour that would result from calling a function using an incompatible pointer type.

### Exception
1. A null pointer constant may be converted into a pointer to a function;
2. A pointer to a function may be converted into void;
3. A function type may be implicitly converted into a pointer to that function type.

Note: exception 3 covers the implicit conversions that commonly occur when:
- A function is called directly, i.e. using a function identifier to denote the function to be called;
- A function is assigned to a function pointer.

## References
C90 [Undefined 24, 27–29], C99 [Undefined 21, 23, 39, 41], C11 [Undefined 24, 26, 41, 44]