# Rule 12.3: The comma operator should not be used

This query implements the MISRA C 2012 Rule 12.3:
> The comma operator should not be used.

## Classification
<table>
<tr><td><b>Category</b></td><td>Advisory</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

### Rationale
Use of the comma operator is generally detrimental to the readability of code, and the same effect can usually be achieved by other means.

### Example
```c
f ( ( 1, 2 ), 3 );   /* Non-compliant - how many parameters? */
```

The following example is non-compliant with this rule and other rules:
```c
for ( i = 0, p = &a[ 0 ]; i < N; ++i, ++p )
{
}
```