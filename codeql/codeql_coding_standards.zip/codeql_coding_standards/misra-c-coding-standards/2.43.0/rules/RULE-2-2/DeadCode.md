# Rule 2.2: A project shall not contain dead code

This query implements the MISRA C 2012 Rule 2.2:
> A project shall not contain dead code.

## Classification

<table>
<tr><td><b>Category</b></td><td>Required</td></tr>
<tr><td><b>Analysis</b></td><td>Undecidable, System</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

### Amplification

Any operation that is executed but whose removal would not affect program behaviour constitutes dead code. Operations that are introduced by language extensions are assumed always to have an effect on program behaviour.

Notes:

1. The behaviour of an embedded system is often determined not just by the nature of its actions, but also by the time at which they occur.
2. unreachable code is not dead code, as it cannot be executed.
3. Initialization is not the same as an assignment operation and is therefore not a candidate for dead code.

### Rationale

The presence of dead code may be indicative of an error in the program’s logic. Since dead code may be removed by a compiler, its presence may cause confusion.

### Exception

1. A cast to void is assumed to indicate a value that is intentionally not being used. The cast is therefore not dead code itself. It is treated as using its operand which is therefore also not dead code.
2. A cast operator whose result is used is not dead code.

### Example

In this example, it is assumed that the object pointed to by `p` is used in other functions.

```c
extern volatile uint16_t v;
extern char *p;
void f ( void )
{
  uint16_t  x;
  ( void ) v;      /* Compliant     - v is accessed for its side effect
                    *                 and the cast to void is permitted
                    *                 by exception                       */
  ( int32_t ) v;   /* Non-compliant - the cast operator is dead          */
  v >> 3;          /* Non-compliant - the >> operator is dead            */
  x = 3;           /* Non-compliant - the = operator is dead
                    *               - x is not subsequently read         */
  *p++;            /* Non-compliant - result of * operator is not used   */
  ( *p )++;        /* Compliant     - *p is incremented                  */
}
```

In the following compliant example, the `__asm` keyword is a language extension, not a function call operation, and is therefore not dead code:

```c
__asm ( "NOP" );
```

In the following example, the function `g` does not contain dead code, and is not itself dead code because it does not contain any operations. However, the call to the function is dead because it could be removed without affecting program behaviour.

```c
void g ( void )
{
  /* Compliant - there are no operations in this function */
}
void h ( void )
{
  g ( );   /* Non-compliant - the call could be removed   */
}
```

### See also

Rule 17.7

## References

- [IEC 61508-7 Section C.5.10]
- [ISO 26262-6 Section 9.4.5]
- [DO-178C Section 6.4.4.3.c]