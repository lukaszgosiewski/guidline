# Rule 11.6: A cast shall not be performed between pointer to void and an arithmetic type

This query implements the MISRA C 2012 Rule 11.6:
> A cast shall not be performed between pointer to void and an arithmetic type.

## Classification
<table>
<tr><td><b>Category</b></td><td>Required</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

### Rationale
Conversion of an integer into a pointer to void results in behaviour that is implementation-defined. Conversion of a pointer to void into an integer may produce a value that cannot be represented in the chosen integer type resulting in undefined behaviour.
Conversion between any non-integer arithmetic type and pointer to void is undefined.

### Exception
An integer constant expression with value 0 may be cast into pointer to void.

### Example
```c
void     *p;
uint32_t  u;
/* Non-compliant - implementation-defined */
p = ( void * ) 0x1234u;
/* Non-compliant - undefined              */
p = ( void * ) 1024.0f;
/* Non-compliant - implementation-defined */
u = ( uint32_t ) p;
```

## References
C90 [Undefined 29; Implementation 24]
C99 [Undefined 21, 41; Implementation J.3.7(1)]
C11 [Undefined 24, 44; Implementation J.3.7(1)]