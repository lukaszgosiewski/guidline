# Rule 16.4: Every switch statement shall have a default label

This query implements the MISRA C 2012 Rule 16.4:
> Every switch statement shall have a default label.

## Classification

<table>
<tr><td><b>Category</b></td><td>Required</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

## Amplification
The switch-clause following the default label shall, prior to the terminating break statement, contain:
- A statement, or
- A comment.

## Rationale
The requirement for a default label is defensive programming. Any statements following the default label are intended to take some appropriate action. If no statements follow the label then the comment can be used to explain why no specific action has been taken.

## Example
```c
int16_t x;
switch ( x )
{
  case 0:
    ++x;
    break;
  case 1:
  case 2:
    break;
                     /* Non-compliant - default label is required */
}

int16_t x;
switch ( x )
{
  case 0:
    ++x;
    break;
  case 1:
  case 2:
    break;
  default:           /* Compliant - default label is present */
    errorflag = 1;   /* should be non-empty if possible */
    break;
}
```

```c
enum Colours
{ RED, GREEN, BLUE } colour;
switch ( colour )
{
  case RED:
    next = GREEN;
    break;
  case GREEN:
    next = BLUE;
    break;
  case BLUE:
    next = RED;
    break;
                     /* Non-compliant - no default label.
                      * Even though all values of the enumeration are
                      * handled there is no guarantee that colour
                      * takes one of those values */
}
```

## See also
Rule 2.1, Rule 16.1