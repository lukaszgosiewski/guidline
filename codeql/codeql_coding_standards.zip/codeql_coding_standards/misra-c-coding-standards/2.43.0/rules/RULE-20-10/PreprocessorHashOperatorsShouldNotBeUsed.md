# Rule 20.10: The # and ## preprocessor operators should not be used

This query implements the MISRA C 2012 Rule 20.10:
> The # and ## preprocessor operators should not be used.

## Classification
<table>
<tr><td><b>Category</b></td><td>Advisory</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

### Rationale
The order of evaluation associated with multiple #, multiple ## or a mix of # and ## preprocessor operators is unspecified. In some cases it is therefore not possible to predict the result of macro expansion.

The use of the ## operator can result in code that is obscure.

Note: Rule 1.3 covers the undefined behaviour that arises if either:
- The result of a # operator is not a valid string literal; or
- The result of a ## operator is not a valid preprocessing token.

### See also
Rule 20.11

## References
C90 [Unspecified 12; Undefined 51, 52]  
C99 [Unspecified 25; Undefined 3, 88, 89]  
C11 [Unspecified 26; Undefined 3, 94, 95]