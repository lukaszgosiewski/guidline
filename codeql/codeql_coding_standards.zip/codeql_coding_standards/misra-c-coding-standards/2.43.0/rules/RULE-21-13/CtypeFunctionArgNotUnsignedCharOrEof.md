# Rule 21.13: Any value passed to a function in `<ctype.h>` shall be representable as an unsigned char or be the value EOF

This query implements the MISRA C 2012 Rule 21.13:
> Any value passed to a function in `<ctype.h>` shall be representable as an unsigned char or be the value EOF.

## Classification

<table>
<tr><td><b>Category</b></td><td>Mandatory</td></tr>
<tr><td><b>Analysis</b></td><td>Undecidable, System</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

## Rationale

The relevant functions from `<ctype.h>` are defined to take an `int` argument where the expected value is either in the range of an unsigned char or is a negative value equivalent to `EOF`. The use of any other values results in undefined behaviour.

## Example

Note: The `int` casts in the following example are required to comply with Rule 10.3.

```c
bool_t f ( uint8_t a ) {
  return (    isdigit ( ( int32_t )  a  )       /* Compliant     */
           && isalpha ( ( int32_t ) 'b' )       /* Compliant     */
           && islower (             EOF )       /* Compliant     */
           && isalpha (             256 ) );    /* Non-compliant */
}
```

## See also

Rule 10.3

## References

C90 [Undefined 63], C99 [Undefined 107], C11 [Undefined 113]