# Rule 21.7: The Standard Library functions `atof`, `atoi`, `atol` and `atoll` of `<stdlib.h>` shall not be used
  
This query implements the MISRA C 2012 Rule 21.7:
> The Standard Library functions `atof`, `atoi`, `atol` and `atoll` of `<stdlib.h>` shall not be used.
  
## Classification

<table>
<tr><td><b>Category</b></td><td>Required</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

## Amplification

The identifiers `atof`, `atoi`, `atol` and `atoll` shall not be used and no macro with one of these names shall be expanded.

## Rationale

These functions have undefined behaviour associated with them when the string cannot be converted.

## References
C90 [Undefined 90], C99 [Undefined 113], C11 [Undefined 119]