# Rule 2.3: A project should not contain unused type declarations

This query implements the MISRA C 2012 Rule 2.3:
> A project should not contain unused type declarations.

## Classification
<table>
<tr><td><b>Category</b></td><td>Advisory</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, System</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

## Rationale
If a type is declared but not used, then it is unclear to a reviewer if the type is redundant or it has been left unused by mistake.

## Example
```c
int16_t unusedtype ( void )
{
  typedef int16_t local_Type;   /* Non-compliant */
  return 67;
}
```