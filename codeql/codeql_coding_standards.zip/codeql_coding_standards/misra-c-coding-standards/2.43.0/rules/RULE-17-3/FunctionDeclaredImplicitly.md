# Rule 17.3: A function shall not be declared implicitly

This query implements the MISRA C 2012 Rule 17.3:
> A function shall not be declared implicitly.

## Classification
<table>
<tr><td><b>Category</b></td><td>Mandatory</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C90</td></tr>
</table>

### Rationale
Provided that a function call is made in the presence of a prototype, a constraint ensures that the number of arguments matches the number of parameters and that each argument can be assigned to its corresponding parameter.

If a function is declared implicitly, a C90 compiler will assume that the function has a return type of int. Since an implicit function declaration does not provide a prototype, a compiler will have no information about the number of function parameters and their types. Inappropriate type conversions may result in passing the arguments and assigning the return value, as well as other undefined behaviour.

### Example
If the function power is declared as:
```c
extern double power ( double d, int n );
```
but the declaration is not visible in the following code then undefined behaviour will occur.
```c
void func ( void )
{
  /* Non-compliant - return type and both argument types incorrect */
  double sq1 = power ( 1, 2.0 );
}
```

### See also
Rule 8.2, Rule 8.4

## References
C90 [Undefined 6, 22, 23]