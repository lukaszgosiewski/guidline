# Rule 15.4: There should be no more than one break or goto statement used to terminate any iteration statement

This query implements the MISRA C 2012 Rule 15.4:
> There should be no more than one break or goto statement used to terminate any iteration statement.

## Classification
<table>
<tr><td><b>Category</b></td><td>Advisory</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

### Rationale
Restricting the number of exits from a loop helps to minimize visual code complexity. The use of one  
break or goto statement allows a single secondary exit path to be created when early loop termination is required.

### Example

1. Compliant Example 1:

    ```c
    for ( x = 0; x < LIMIT; ++x )
    {
      if ( ExitNow ( x ) )
      {
        break;
      }
      for ( y = 0; y < x; ++y )
      {
        if ( ExitNow ( LIMIT - y ) )
        {
          break;
        }
      }
    }
    ```

2. Non-Compliant Example:

    ```c
    for ( x = 0; x < LIMIT; ++x )
    {
      if ( BreakNow ( x ) )
      {
        break;
      }
      else if ( GotoNow ( x ) )
      {
        goto EXIT;
      }
      else
      {
        KeepGoing ( x );
      }
    }
    EXIT:
      ;
    ```

3. Compliant and Non-compliant Example:

    ```c
    while ( x != 0u )
    {
      x = calc_new_x ( );
      if ( x == 1u )
      {
        break;
      }
      while ( y != 0u )
      {
        y = calc_new_y ( );
        if ( y == 1u )
        {
          goto L1;
        }
      }
    }
    L1:
    z = x + y;
    ```

### See also
Rule 15.1, Rule 15.2, Rule 15.3