# Rule 21.21: The Standard Library function system of `<stdlib.h>` shall not be used

This query implements the MISRA C 2012 Rule 21.21:
> The Standard Library function system of `<stdlib.h>` shall not be used.

## Classification
<table>
<tr><td><b>Category</b></td><td>Required</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

### Amplification
The identifier `system` shall not be used and no macro with this name shall be expanded.

### Rationale
This function has undefined and implementation-defined behaviour associated with it. Errors related to the use of `system` are a common cause of security vulnerabilities.

## References
C90 [Implementation 73]  
C99 [Undefined 175; Implementation J.3.2(11), J.3.12(38)]  
C11 [Undefined 186; Implementation J.3.2(12), J.3.12(40)]