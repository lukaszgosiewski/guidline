# Rule 3.1: The character sequences /* and // shall not be used within a comment

This query implements the MISRA C 2012 Rule 3.1:
> The character sequences /* and // shall not be used within a comment.

## Classification
<table>
<tr><td><b>Category</b></td><td>Required</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

## Rationale
If a comment starting sequence, /* or //, occurs within a /* comment, it is quite likely to be caused by a missing */ comment ending sequence.
If a comment starting sequence occurs within a // comment, it is probably because a region of code has been commented-out using //.

## Exception
1. Uniform resource identifiers, of the form {scheme}://{path}, are permitted within comments.
2. The sequence // is permitted within a // comment.

## Example
Consider the following code fragment:
/* some comment, end comment marker accidentally omitted
<<New Page>>
Perform_Critical_Safety_Function( X );
/* this comment is non-compliant */
In reviewing the page containing the call to the function, the assumption is that it is executed code. Because of the accidental omission of the end comment marker, the call to the safety critical function will not be executed.

In the following C99 example, the presence of // comments changes the meaning of the program:
```c
x = y // /*
     + z
     // */
   ;
```
This gives `x = y + z;` but would have been `x = y;` in the absence of the two // comment start sequences.

The following example demonstrates the use of a URI in a comment, and is compliant by exception 1.
```c
/*
** The MISRA C:2012 example suite can be found at
** https://gitlab.com/MISRA/MISRA-C/MISRA-C-2012
*/
```

## References
Dir 4.4