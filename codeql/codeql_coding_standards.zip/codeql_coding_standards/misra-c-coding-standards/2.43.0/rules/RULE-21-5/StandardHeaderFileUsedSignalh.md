# Rule 21.5: The standard header file `<signal.h>` shall not be used

This query implements the MISRA C 2012 Rule 21.5:
> The standard header file `<signal.h>` shall not be used.

## Classification
<table>
<tr><td><b>Category</b></td><td>Required</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

## Amplification
The standard header file `<signal.h>` shall not be `#include`'d, and none of the features that are specified as being provided by `<signal.h>` shall be used.

## Rationale
Signal handling contains implementation-defined and undefined behaviour.

## References
C90 [Undefined 67–69; Implementation 48–52]  
C99 [Undefined 122–127; Implementation J.3.12(12)]  
C11 [Undefined 128–135; Implementation J.3.12(14)]  
[Koenig 74]