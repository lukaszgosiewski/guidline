# Rule 21.17: Use of the string handling functions from `<string.h>` shall not result in accesses beyond the bounds of the objects referenced by their pointer parameters

This query implements the MISRA C 2012 Rule 21.17:
> Use of the string handling functions from `<string.h>` shall not result in accesses beyond the bounds of the objects referenced by their pointer parameters.

## Classification
<table>
<tr><td><b>Category</b></td><td>Mandatory</td></tr>
<tr><td><b>Analysis</b></td><td>Undecidable, System</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

### Amplification
The relevant string handling functions from `<string.h>` are:
`strcat`, `strchr`, `strcmp`, `strcoll`, `strcpy`, `strcspn`, `strlen`, `strpbrk`, `strrchr`, `strspn`, 
`strstr`, `strtok`

### Rationale
Incorrect use of a function listed above may result in a read or write access beyond the bounds of an 
object passed as a parameter, resulting in undefined behaviour.

### Example
```c
char string[] = "Short";
void f1 ( const char *str )
{
  /*
   * Non-compliant use of strcpy as it results in writes beyond the end of 'string'
   */
  ( void ) strcpy ( string, "Too long to fit" );
  
  /*
   * Compliant use of strcpy as 'string' is only modified if 'str' will fit.
   */
  if ( strlen ( str ) < ( sizeof ( string ) - 1u ) )
  {
    ( void ) strcpy ( string, str );
  }
}

size_t f2 ( void )
{
  char text[ 5 ] = "Token";
  
  /*
   * The following is non-compliant as it results in reads beyond
   * the end of 'text' as there is no null terminator.
   */
  return strlen ( text );
}
```

### See also
Rule 21.18

## References
C90 [Undefined 96], C99 [Undefined 103, 180], C11 [Undefined 109, 191]