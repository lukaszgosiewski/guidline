# Rule 21.3: The memory allocation and deallocation functions of <stdlib.h> shall not be used

This query implements the MISRA C 2012 Rule 21.3:
> The memory allocation and deallocation functions of `<stdlib.h>` shall not be used.

## Classification
<table>
<tr><td><b>Category</b></td><td>Required</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

## Amplification
The identifiers `calloc`, `malloc`, `realloc`, `aligned_alloc`, and `free` shall not be used and no macro with one of these names shall be expanded.

## Rationale
Use of dynamic memory allocation and deallocation routines provided by the Standard Library can lead to undefined behaviour, for example:
- Memory that was not dynamically allocated is subsequently freed;
- A pointer to freed memory is used in any way;
- Accessing allocated memory before storing a value into it.

Note: This rule is a specific instance of Dir 4.12.

## See also
Dir 4.12, Rule 18.7, Rule 22.1, Rule 22.2

## References
C90 [Unspecified 19; Undefined 9, 91, 92; Implementation 69]  
C99 [Unspecified 39, 40; Undefined 8, 9, 168–171; Implementation J.3.12(35)]  
C11 [Unspecified 42, 43; Undefined 9, 10, 177–181; Implementation J.3.12(37)]