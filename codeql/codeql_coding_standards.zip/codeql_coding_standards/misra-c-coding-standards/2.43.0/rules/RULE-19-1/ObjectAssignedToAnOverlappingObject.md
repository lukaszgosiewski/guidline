# Rule 19.1: An object shall not be assigned or copied to an overlapping object

This query implements the MISRA C 2012 Rule 19.1:
> An object shall not be assigned or copied to an overlapping object.

## Classification

<table>
<tr><td><b>Category</b></td><td>Mandatory</td></tr>
<tr><td><b>Analysis</b></td><td>Undecidable, System</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

### Rationale
The behaviour is undefined when two objects are created which have some overlap in memory and  
one is assigned or copied to the other.

### Exception
The following are permitted because the behaviour is well-defined:
1. Assignment between two objects that overlap exactly and have compatible types (ignoring their type qualifiers)
2. Copying between objects that overlap partially or completely using the Standard Library function `memmove`.

### Example
This example also violates Rule 19.2 because it uses unions.
```c
void fn ( void ) {
    union {
        int16_t i;
        int32_t j;
    } a = { 0 };

    a.j = a.i;   /* Non-compliant */
}

#include <string.h>
int16_t a[ 20 ];
void f ( void ) {
    memcpy ( &a[ 5 ], &a[ 4 ], 2u * sizeof ( a[ 0 ] ) );  /* Non-compliant */
}

void g ( void ) {
    int16_t *p = &a[ 0 ];
    int16_t *q = &a[ 0 ];
    *p = *q;   /* Compliant - exception 1 */
}
```
### See also
Rule 19.2

## References
- C90 [Undefined 34, 55]
- C99 [Undefined 51, 94]
- C11 [Undefined 54, 100]