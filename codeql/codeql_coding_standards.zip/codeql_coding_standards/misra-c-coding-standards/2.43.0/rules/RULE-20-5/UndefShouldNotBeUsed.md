# Rule 20.5: `#undef` should not be used

This query implements the MISRA C 2012 Rule 20.5:
> #undef should not be used.

## Classification
<table>
<tr><td><b>Category</b></td><td>Advisory</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

## Rationale
The use of #undef can make it unclear which macros exist at a particular point within a translation unit.

## Example
```c
#define QUALIFIER volatile
#undef QUALIFIER             /* Non-compliant */
void f (QUALIFIER int32_t p)
{
  while (p != 0)
  {
    ;                        /* Wait...  */
  }
}
```