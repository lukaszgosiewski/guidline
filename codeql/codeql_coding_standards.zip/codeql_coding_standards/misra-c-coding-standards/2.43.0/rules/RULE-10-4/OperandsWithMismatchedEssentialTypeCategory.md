# Rule 10.4: Both operands of an operator in which the usual arithmetic conversions are performed shall have the same essential type category

This query implements the MISRA C 2012 Rule 10.4:
> Both operands of an operator in which the usual arithmetic conversions are performed shall have the same essential type category.

## Classification
<table>
<tr><td><b>Category</b></td><td>Required</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

## Amplification
This rule applies to operators that are described in the usual arithmetic conversions section in the C Standard. This includes all the binary operators, excluding the shift, logical `&&`, logical `||` and comma operators. In addition, the second and third operands of the ternary operator are covered by this rule. Note: the increment and decrement operators are not covered by this rule.

## Rationale
The C language allows the programmer considerable freedom and will permit conversions between different arithmetic types to be performed automatically. However, the use of these implicit conversions can lead to unintended results, with the potential for loss of value, sign or precision. Further details of concerns with the C type system can be found in Appendix C.

The use of stronger typing, as enforced by the MISRA essential type model, allows implicit conversions to be restricted to those that should then produce the answer expected by the developer.

## Exception
The following are permitted to allow a common form of character manipulation to be used:
1. The binary `+` and `+=` operators may have one operand with essentially character type and the other operand with an essentially signed or essentially unsigned type.
2. The binary `-` and `-=` operators may have a left-hand operand with essentially character type and a right-hand operand with an essentially signed or essentially unsigned type.

Operations involving mixed real and complex operands have well-defined semantics and are therefore permitted:
3. The operators covered by this rule may have one operand with essentially real floating type and the other operand with essentially complex floating type. In the case of the conditional operator, this exception applies to the second and third operands.

## Example
```c
enum enuma { A1, A2, A3 } ena;
enum enumb { B1, B2, B3 } enb;
```
The following are compliant as they have the same essential type category:
```c
ena > A1
u8a + u16b
```
The following is compliant by exception 1:
```c
cha += u8a
```
The following is compliant by exception 3.
```c
cf32a += f32a;   /* complex floating and real floating */
```
The following is non-compliant with this rule and also violates Rule 10.3:
```c
s8a += u8a       /* signed and unsigned */
```
The following are non-compliant:
```c
u8b + 2          /* unsigned and signed */
enb > A1         /* enum<enumb> and enum<enuma> */
ena == enb       /* enum<enuma> and enum<enumb> */
```

## See also
Rule 10.3, Rule 10.7

## References
C90 [Implementation 21], C99 [Implementation J.3.6(4)], C11 [Implementation J.3.6(5)]