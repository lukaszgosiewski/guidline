# Rule 12.1: The precedence of operators within expressions should be made explicit

This query implements the MISRA C 2012 Rule 12.1:
> The precedence of operators within expressions should be made explicit.

## Classification

<table>
<tr><td><b>Category</b></td><td>Advisory</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

## Amplification

The following table is used in the definition of this rule.

| Description | Operator or Operand | Precedence |
|-------------|---------------------|------------|
| Primary     | identifier, constant, string literal, ( expression ), generic selection | 16 (high) |
| Postfix     | [] () . -> ++ -- {} | 15 |
| Unary       | ++ -- & * + - ~ ! sizeof _Alignof defined | 14 |
| Cast        | ()                  | 13 |
| Multiplicative | * / %            | 12 |
| Additive    | + -                 | 11 |
| Bitwise shift | << >>             | 10 |
| Relational  | < > <= >=           | 9 |
| Equality    | == !=               | 8 |
| Bitwise AND | &                   | 7 |
| Bitwise XOR | ^                   | 6 |
| Bitwise OR  | &#124;              | 5 |
| Logical AND | &&                  | 4 |
| Logical OR  | &#124;&#124;        | 3 |
| Conditional | ?:                  | 2 |
| Assignment  | = *= /= %= += -= <<= >>= &= ^= |= | 1 |
| Comma       | ,                   | 0 (low) |

The precedence used in this table are chosen to allow a concise description of the rule. They are not necessarily the same as those that might be encountered in other descriptions of operator precedence.

For the purposes of this rule, the precedence of an expression is the precedence of the element (operand or operator) at the root of the parse tree for that expression.

For example: the parse tree for the expression `a << b + c` can be represented as:

```
     <<
    /  \
   a    +
       / \
      b   c
```

The element at the root of this parse tree is `<<` so the expression has precedence 10.

The following advice is given:
- The operand of the `sizeof` operator should be enclosed in parentheses.
- An expression whose precedence is in the range 2 to 12 should have parentheses around any operand that has both:
  - Precedence of less than 13, and
  - Precedence greater than the precedence of the expression.

## Rationale

The C language has a relatively large number of operators and their relative precedence is not intuitive. This can lead less experienced programmers to make mistakes. Using parentheses to make operator precedence explicit removes the possibility that the programmer's expectations are incorrect. It also makes the original programmer's intention clear to reviewers or maintainers of the code.

It is recognized that overuse of parentheses can clutter the code and reduce its readability. This rule aims to achieve a compromise between code that is hard to understand because it contains either too many or too few parentheses.

## Examples

**Compliant Examples:**

```c
a[ i ]->n;        // no need to write ( a[ i ] )->n
*p++;             // no need to write *( p++ )
```

```c
sizeof ( x ) + y; // or sizeof ( x + y )
x = ( a == b ) ? a : ( a - b );
x = a << ( b + c );
if ( a && b && c ) { }
#if defined ( X ) && ( ( X + Y ) > Z )
#if !defined ( X ) && defined ( Y )
```

**Non-compliant Examples:**

```c
sizeof x + y;
x = a == b ? a : a - b;
```

Note: this rule does not require the operands of a `,` operator to be parenthesized. Use of the `,` operator is prohibited by Rule 12.3.

```c
x = a, b; // parsed as ( x = a ), b
```

## References

None.