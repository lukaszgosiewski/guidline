# Rule 7.3: The lowercase character “l” shall not be used in a literal suffix

This query implements the MISRA C 2012 Rule 7.3:
> The lowercase character “l” shall not be used in a literal suffix.

## Classification
<table>
<tr><td><b>Category</b></td><td>Required</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

## Rationale
Using the uppercase suffix “L” removes the potential ambiguity between “1” (digit 1) and “l” (letter “el”) when declaring literals.

## Example
Note: the examples containing the long long suffix are applicable only to C99.
```c
const int64_t    a = 0L;
const int64_t    b = 0l;     /* Non-compliant */
const uint64_t   c = 0Lu;
const uint64_t   d = 0lU;    /* Non-compliant */
const uint64_t   e = 0ULL;
const uint64_t   f = 0Ull;   /* Non-compliant */
const int128_t   g = 0LL;
const int128_t   h = 0ll;    /* Non-compliant */
const float128_t m = 1.2L;
const float128_t n = 2.4l;   /* Non-compliant */
```