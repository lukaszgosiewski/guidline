# Rule 21.9: The Standard Library functions bsearch and qsort of `<stdlib.h>` shall not be used

This query implements the MISRA C 2012 Rule 21.9:
> The Standard Library functions bsearch and qsort of `<stdlib.h>` shall not be used.

## Classification
<table>
<tr><td><b>Category</b></td><td>Required</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

## Amplification
The identifiers `bsearch` and `qsort` shall not be used and no macro with one of these names shall be expanded.

## Rationale
If the comparison function does not behave consistently when comparing elements, or it modifies any of the elements, the behaviour is undefined.  
Note: the unspecified behaviour, which relates to the treatment of elements that compare as equal, can be avoided by ensuring that the comparison function never returns 0. When two elements are otherwise equal, the comparison function could return a value that indicates their relative order in the initial array.

The implementation of `qsort` is likely to be recursive and will therefore place unknown demands on stack resources. This is of concern in embedded systems as the stack is likely to be a fixed, often small, size.

## References
C90 [Unspecified 20, 21]  
C99 [Unspecified 41, 42; Undefined 176–178]  
C11 [Unspecified 46, 47; Undefined 187–189]