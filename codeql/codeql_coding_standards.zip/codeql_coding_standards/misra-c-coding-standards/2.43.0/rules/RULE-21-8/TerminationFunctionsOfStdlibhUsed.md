# Rule 21.8: The Standard Library termination functions of `<stdlib.h>` shall not be used

This query implements the MISRA C 2012 Rule 21.8:
> The Standard Library termination functions of `<stdlib.h>` shall not be used.

## Classification
<table>
<tr><td><b>Category</b></td><td>Required</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

## Amplification
The termination functions are `abort`, `exit`, `_Exit` and `quick_exit`.
Identifiers with these names shall not be used and no macro with one of these names shall be expanded.

## Rationale
These functions have undefined and implementation-defined behaviours associated with them.

## References
C90 [Undefined 93; Implementation 70–71]  
C99 [Undefined 172; Implementation J.3.12(36–37)]  
C11 [Undefined 182,185; Implementation J.3.12(38-39)]