# Rule 7.1: Octal constants shall not be used

This query implements the MISRA C 2012 Rule 7.1:
> Octal constants shall not be used.

## Classification
<table>
<tr><td><b>Category</b></td><td>Required</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

### Rationale
Developers writing constants that have a leading zero might expect them to be interpreted as decimal constants.
Note: this rule does not apply to octal escape sequences because the use of a leading `\` character means that there is less scope for confusion.

### Exception
The integer constant zero (written as a single numeric digit) is, strictly speaking, an octal constant, but is a permitted exception to this rule.

### Example
```c
extern uint16_t code[10];
code[1] = 109;   /* Compliant     - decimal 109 */
code[2] = 100;   /* Compliant     - decimal 100 */
code[3] = 052;   /* Non-Compliant - decimal 42  */
code[4] = 071;   /* Non-Compliant - decimal 57  */
```

## References
[Koenig 9]