# Rule 11.3: A conversion shall not be performed between a pointer to object type and a pointer to a different object type

This query implements the MISRA C 2012 Rule 11.3:
> A conversion shall not be performed between a pointer to object type and a pointer to a different object type.

## Classification
<table>
<tr><td><b>Category</b></td><td>Required</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

### Amplification
This rule applies to the unqualified types that are pointed to by the pointers.

### Rationale
Converting a pointer to object into a pointer to a different object may result in a pointer that is not correctly aligned, resulting in undefined behaviour.

### Exception
It is permitted to convert a pointer to a non-qualified object type into a pointer to one of the object types char, signed char or unsigned char. The C Standard guarantees that pointers to these types can be used to access the individual bytes of an object.

### Example
```c
uint8_t  *p1;
uint32_t *p2;

/* Non-compliant - possible incompatible alignment */
p2 = ( uint32_t * ) p1;

extern uint32_t read_value ( void );
extern void print ( uint32_t n );

void f ( void )
{
  uint32_t  u    = read_value ( );
  uint16_t *hi_p = ( uint16_t * ) &u;   /* Non-compliant even though
                                         * probably correctly aligned   */
  *hi_p = 0;     /* Attempt to clear high 16-bits on big-endian machine */
  print ( u );   /* Line above may appear not to have been performed    */
}

/* Compliant example */
const short *p;
const volatile short *q;
q = ( const volatile short * ) p;   /* Compliant */

/* Non-compliant example */
int * const * pcpi;
const int * const * pcpci;
pcpci = ( const int * const * ) pcpi;
```

### See also
Rule 11.4, Rule 11.5, Rule 11.8, Rule 18.1

## References
C90 [Undefined 20], C99 [Undefined 22, 34], C11 [Undefined 25, 37]