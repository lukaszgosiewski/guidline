# Rule 17.7: The value returned by a function having non-void return type shall be used

This query implements the MISRA C 2012 Rule 17.7:
> The value returned by a function having non-void return type shall be used.

## Classification
<table>
<tr><td><b>Category</b></td><td>Required</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

## Rationale
It is possible to call a function without using the return value, which may be an error. If the return value of a function is intended not to be used explicitly, it should be cast to the void type. This has the effect of using the value without violating Rule 2.2.

## Example
```c
uint16_t func ( uint16_t para1 )
{
  return para1;
}

uint16_t x;
void discarded ( uint16_t para2 )
{
  func ( para2 );            /* Non-compliant - value discarded */
  ( void ) func ( para2 );   /* Compliant                       */
  x = func ( para2 );        /* Compliant                       */
}
```

## See also
Dir 4.7, Rule 2.2