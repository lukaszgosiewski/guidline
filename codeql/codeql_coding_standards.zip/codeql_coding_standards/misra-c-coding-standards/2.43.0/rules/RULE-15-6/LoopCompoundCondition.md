# Rule 15.6: The body of an iteration-statement or a selection-statement shall be a compound-statement

This query implements the MISRA C 2012 Rule 15.6:
> The body of an iteration-statement or a selection-statement shall be a compound-statement.

## Classification
<table>
<tr><td><b>Category</b></td><td>Required</td></tr>
<tr><td><b>Analysis</b></td><td>Decidable, Single Translation Unit</td></tr>
<tr><td><b>Applies to</b></td><td>C90, C99, C11</td></tr>
</table>

## Amplification
The body of an iteration-statement (while, do ... while or for) or a selection-statement (if, else, switch) shall be a compound-statement.

## Rationale
It is possible for a developer to mistakenly believe that a sequence of statements forms the body of an iteration-statement or selection-statement by virtue of their indentation. The accidental inclusion of a semi-colon after the controlling expression is a particular danger, leading to a null control statement. Using a compound-statement clearly defines which statements actually form the body. Additionally, it is possible that indentation may lead a developer to associate an else statement with the wrong if.

## Exception
An if statement immediately following an else need not be contained within a compound-statement.

## Example
The layout for the compound-statement and its enclosing braces are style issues which are not addressed by this document; the style used in the following examples is not mandatory.

Non-compliant example:
```c
while (data_available)
  process_data();             /* Non-compliant */
```

A potential error caused by indentation:
```c
while (data_available)
  process_data();             /* Non-compliant */
  service_watchdog();
```
where `service_watchdog()` should have been added to the loop body. The use of a compound-statement significantly reduces the chance of this happening.

Another non-compliant example:
```c
if (flag_1)
  if (flag_2)                 /* Non-compliant */
    action_1();               /* Non-compliant */
else
  action_2();                 /* Non-compliant */
```

Compliant behavior:
```c
if (flag_1)
{
  if (flag_2)
  {
    action_1();
  }
  else
  {
    action_2();
  }
}
```
The use of compound-statements ensures that if and else associations are clearly defined. The exception allows the use of else if, as shown below:
```c
if (flag_1)
{
  action_1();
}
else if (flag_2)              /* Compliant by exception */
{
  action_2();
}
else
{
  ;  /* no action */
}
```

Non-compliant example showing potential error from a spurious semi-colon:
```c
while (flag);                 /* Non-compliant */
{
  flag = fn();
}
```

Compliant method of writing a loop with an empty body:
```c
while (!data_available)
{
}
```