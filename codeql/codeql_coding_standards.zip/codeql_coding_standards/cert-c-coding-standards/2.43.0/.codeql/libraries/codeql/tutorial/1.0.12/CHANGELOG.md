## 1.0.12

No user-facing changes.

## 1.0.11

No user-facing changes.

## 1.0.10

No user-facing changes.

## 1.0.9

No user-facing changes.

## 1.0.8

No user-facing changes.

## 1.0.7

No user-facing changes.

## 1.0.6

No user-facing changes.

## 1.0.5

No user-facing changes.

## 1.0.4

No user-facing changes.

## 1.0.3

No user-facing changes.

## 1.0.2

No user-facing changes.

## 1.0.1

No user-facing changes.

## 1.0.0

### Breaking Changes

* CodeQL package management is now generally available, and all GitHub-produced CodeQL packages have had their version numbers increased to 1.0.0.

## 0.2.16

No user-facing changes.

## 0.2.15

No user-facing changes.

## 0.2.14

No user-facing changes.

## 0.2.13

No user-facing changes.

## 0.2.12

No user-facing changes.

## 0.2.11

No user-facing changes.

## 0.2.10

No user-facing changes.

## 0.2.9

No user-facing changes.

## 0.2.8

No user-facing changes.

## 0.2.7

No user-facing changes.

## 0.2.6

No user-facing changes.

## 0.2.5

No user-facing changes.

## 0.2.4

No user-facing changes.

## 0.2.3

No user-facing changes.

## 0.2.2

No user-facing changes.

## 0.2.1

No user-facing changes.

## 0.2.0

No user-facing changes.

## 0.1.5

No user-facing changes.

## 0.1.4

No user-facing changes.

## 0.1.3

No user-facing changes.

## 0.1.2

No user-facing changes.

## 0.1.1

No user-facing changes.

## 0.1.0

No user-facing changes.

## 0.0.12

No user-facing changes.

## 0.0.11

No user-facing changes.

## 0.0.10

No user-facing changes.

## 0.0.9

No user-facing changes.

## 0.0.8

No user-facing changes.

## 0.0.7

No user-facing changes.

## 0.0.6

No user-facing changes.

## 0.0.5

No user-facing changes.

## 0.0.4

No user-facing changes.

## 0.0.3

No user-facing changes.

## 0.0.2

No user-facing changes.

## 0.0.1

### Minor Analysis Improvements

* Initial release. Contains the library for the CodeQL detective tutorials, helping new users learn to write CodeQL queries.
