## 1.0.12

No user-facing changes.

## 1.0.11

No user-facing changes.

## 1.0.10

No user-facing changes.

## 1.0.9

No user-facing changes.

## 1.0.8

No user-facing changes.

## 1.0.7

No user-facing changes.

## 1.0.6

No user-facing changes.

## 1.0.5

No user-facing changes.

## 1.0.4

No user-facing changes.

## 1.0.3

No user-facing changes.

## 1.0.2

No user-facing changes.

## 1.0.1

No user-facing changes.

## 1.0.0

### Breaking Changes

* CodeQL package management is now generally available, and all GitHub-produced CodeQL packages have had their version numbers increased to 1.0.0.

## 0.0.3

No user-facing changes.

## 0.0.2

No user-facing changes.

## 0.0.1

### New Features

* Initial release. Adds a library to implement type-flow analysis.
